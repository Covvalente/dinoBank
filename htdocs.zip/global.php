<?php
require_once('kernel/configs.php');
